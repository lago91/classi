Source for the Angular Cognito Test

Youtube for this showing how it runs.

https://youtu.be/ROwjNYlxMAs